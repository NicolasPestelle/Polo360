<?php

defined('C5_EXECUTE') or die("Access Denied.");
class DashboardExtendInstallController extends Concrete5_Controller_Dashboard_Extend_Install {}