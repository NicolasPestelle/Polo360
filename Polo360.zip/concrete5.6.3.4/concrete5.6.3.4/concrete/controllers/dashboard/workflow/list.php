<?php
defined('C5_EXECUTE') or die("Access Denied.");
class DashboardWorkflowListController extends Concrete5_Controller_Dashboard_Workflow_List {
	

	
}