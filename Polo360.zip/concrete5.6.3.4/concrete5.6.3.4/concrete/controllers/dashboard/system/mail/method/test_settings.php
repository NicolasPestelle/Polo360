<?php
defined('C5_EXECUTE') or die("Access Denied.");

class DashboardSystemMailMethodTestSettingsController extends Concrete5_Controller_Dashboard_System_Mail_Method_TestSettings {
}