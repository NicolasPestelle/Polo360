<?php

defined('C5_EXECUTE') or die("Access Denied.");
Loader::block('form');

class DashboardReportsController extends Concrete5_Controller_Dashboard_Reports {


}