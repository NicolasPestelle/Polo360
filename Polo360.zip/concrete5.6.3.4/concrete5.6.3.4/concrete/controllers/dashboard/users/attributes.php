<?php
defined('C5_EXECUTE') or die("Access Denied.");
class DashboardUsersAttributesController extends Concrete5_Controller_Dashboard_Users_Attributes {

}