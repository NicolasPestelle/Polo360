<?php
defined('C5_EXECUTE') or die("Access Denied.");
class ProfileController extends Concrete5_Controller_Profile {
	
}