<?php
defined('C5_EXECUTE') or die("Access Denied.");
$mapObj=$controller;
$this->inc('form_setup_html.php',array( 'mapObj' => $controller ));