<?php
	defined('C5_EXECUTE') or die("Access Denied.");
	class GuestbookBlockController extends Concrete5_Controller_Block_Guestbook {		
	
	}
	
	class GuestBookBlockEntry extends Concrete5_Controller_Block_GuestbookEntry {

	
	}