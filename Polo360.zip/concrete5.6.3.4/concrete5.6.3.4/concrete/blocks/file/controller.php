<?php
	defined('C5_EXECUTE') or die("Access Denied.");
	
	class FileBlockController extends Concrete5_Controller_Block_File {

		
	}